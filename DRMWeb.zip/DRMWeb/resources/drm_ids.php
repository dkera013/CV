<?php



function init_database()
{
    $link = mysql_connect('158.125.161.156', 'username', 'password') or die('Could not connect: ' . mysql_error());
    mysql_select_db('Energy_mon') or die('Could not select database');
    return $link;
}

function print_result($query)
{
   $result = mysql_query($query) or die('Query failed: ' . mysql_error());
    //create an array
    $rows = array();
    while($row =mysql_fetch_assoc($result))
    {
        $rows[] = $row;
    }
    echo json_encode($rows);
   
    mysql_free_result($result);
}

//works
function get_all_data()
{
    $query = "SELECT tb1.energy_mon_id, ambient_tmp AS last_ambient_tmp, remote_tmp AS last_remote_tmp, date, time
    FROM (SELECT energy_mon_id, MAX(measurment_environment_id) AS last_meas FROM `bk_measurement_environment_tbl`
    GROUP BY energy_mon_id) tb1
    JOIN (SELECT * FROM `bk_measurement_environment_tbl`) tb2 ON tb1.energy_mon_id=tb2.energy_mon_id AND tb1.last_meas=tb2.measurment_environment_id
    ORDER BY energy_mon_id ASC";
    
    print_result($query);
}



//this is the activity flow

$database = init_database();


//if you use header it opens a json file
//header("Content-Type: text/json");

// Check for the path elements to see if we have a book id in the request path
$path = $_SERVER[PATH_INFO];    
if ($path != null)
{
    $path_params = spliti ("/", $path);
}



if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
      
    get_all_data();
    
       
}


mysql_close($database);






?>
