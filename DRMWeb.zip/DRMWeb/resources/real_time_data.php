<?php
$host = "158.125.161.156";
$username = "USERNAME";
$password = "PASSWORD";
$dbname = "Energy_mon";
//$data = json_decode(file_get_contents("php://input"));

// Set maximum mysql connection/socket timeout IF needed (it's handled in th controllers.js for now as an $http timeout),
// might need to change that either with droppibing the controller at state change or as in the following 2 lines
//ini_set('mysql.connect_timeout', 30);
//ini_set('default_socket_timeout', 30);

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
} 

if (isset($_POST['drmIds']) ){

	$sql = "SELECT tb1.energy_mon_id, ambient_tmp AS last_ambient_tmp, remote_tmp AS last_remote_tmp, date, time FROM (SELECT energy_mon_id, MAX(measurment_environment_id) AS last_meas FROM `bk_measurement_environment_tbl` GROUP BY energy_mon_id) tb1 JOIN (SELECT * FROM `bk_measurement_environment_tbl`) tb2 ON tb1.energy_mon_id=tb2.energy_mon_id AND tb1.last_meas=tb2.measurment_environment_id ORDER BY energy_mon_id ASC";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
    // output data of each row
		$rows = array();
		while($r = mysqli_fetch_assoc($result)) {
			$rows[] = $r;
		}
	} else {
		echo "0 results";
	}
}elseif (isset($_POST['limit']) && isset($_POST['drmId'])){

	$sql = "SELECT * FROM  `bk_measurement_raw_electric_tbl` WHERE `energy_mon_id`=".$_POST['drmId']." ORDER BY `bk_measurement_raw_electric_tbl`.`measurment_raw_electric_id`  DESC LIMIT 0, ".$_POST['limit'];
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
    // output data of each row
		$rows = array();
		while($r = mysqli_fetch_assoc($result)) {
			$rows[] = $r;
		}
	} else {
		echo "0 results";
	}
}

print json_encode($rows);
$conn->close();
?>