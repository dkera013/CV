<?php



function init_database()
{
    $link = mysql_connect('158.125.161.156', 'username', 'password') or die('Could not connect: ' . mysql_error());
    mysql_select_db('Energy_mon') or die('Could not select database');
    return $link;
}

function print_result($query)
{
   $result = mysql_query($query) or die('Query failed: ' . mysql_error());
    //create an array
    $rows = array();
    while($row =mysql_fetch_assoc($result))
    {
        $rows[] = $row;
    }
    echo json_encode($rows);
   
    mysql_free_result($result);
}

//works
function get_average()
{
    $query = "SELECT SUM( current_a ) AS energy_consumption FROM bk_measurement_raw_electric_tbl WHERE energy_mon_id =0";
    
    print_result($query);
}

//function get_max($energy_mon_id)
//{
//    
//    $query = "SELECT MAX(current_a) FROM bk_measurement_raw_electric_tbl WHERE  energy_mon_id = 0";  
//    print_result($query);
//}

//this is the activity flow

$database = init_database();


//if you use header it opens a json file
//header("Content-Type: text/json");

// Check for the path elements to see if we have a book id in the request path
$path = $_SERVER[PATH_INFO];    
if ($path != null)
{
    $path_params = spliti ("/", $path);
}



if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
    
    
    
    get_average();
    
    
    
}


mysql_close($database);






?>