<?php


$url = 'http://www.bmreports.com/bsp/additional/soapfunctions.php?element=systemprices&submit=Invoke';

$client = curl_init($url);
curl_setopt($client, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec($client);
curl_close($client);

$xml = simplexml_load_string($response);


//
//foreach ($xml->SSB as $ssb) {
//	echo "$ssb->SD, $ssb->SP, $ssb->SSP, $ssb->SBP <br/>\n";
//}

echo json_encode($xml);
?>