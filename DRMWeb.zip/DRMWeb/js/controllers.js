/**
 * INSPINIA - Responsive Admin Theme
 * Copyright 2014 Webapplayers.com
 *
 */


/**
 * MainCtrl - controller
 */
function MainCtrl() {

    this.userName = 'Example user';
    this.helloText = 'KPIs';
    this.descriptionText = 'It is an application skeleton for a typical AngularJS web app. You can use it to quickly bootstrap your angular webapp projects and dev environment for these projects.';
 
    

};

function idCtrlDimi($scope, $http, $interval, $rootScope){

    var idGet = function(){
        $http({
            url: 'resources/real_time_data.php',
            // url: 'http://localhost:8080/drm_ids', // Node.js
            method: 'POST',
            timeout: 1000,
            data: 'drmIds',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        }).success(
            function(response){
                if(response[0].energy_mon_id){
                    //$scope.text = response[0].time;
                    $scope.data.availableOptions = [0];
                    for (var i=0; i<response.length; i++) {
                        console.log(response[i].energy_mon_id);
                        //$scope.data.availableOptions[i].id = response[i].energy_mon_id;
                        $scope.data.availableOptions.push({id: response[i].energy_mon_id});
                        //Temperature update code follows:
                        if($scope.drmId == response[i].energy_mon_id){
                            $scope.time_tmp = response[i].time
                            $scope.date_tmp = response[i].date
                            $scope.ambient_tmp = response[i].last_ambient_tmp/100;
                            $scope.remote_tmp = response[i].last_remote_tmp/100;
                        }
                    }
                } else{
                    console.log("invalid response");
                }
            }
        ).error( 
            function(response){
                console.log(response[0]);
            }
        );
    };

    $scope.data = {
    availableOptions: [0],
    selectedOption: {id: '0'} //This sets the default value of the select in the ui
    };

    idGet();

    var interval = $interval(idGet, 500);
    $scope.$on("$destroy", function () { $interval.cancel(interval); });

    $scope.$watch("data.selectedOption.id",function(newVal,oldVal){
        $scope.drmId = newVal;
    });
};

function energyChartCtrlDimi($scope, $http, $interval, $rootScope) {

    $scope.refreshInterval = 1; // refreshInterval is in seconds
    $scope.valueLimit = 30;
    //$scope.drmId = $rootScope.drmId;
    $scope.connectionLabel = "Database Unreachable";
    $scope.connectionLabelColor = "label-danger";

    var chartUpdate = function(){
        $http({
            url: 'resources/real_time_data.php',
            //url: 'http://localhost:8080/energy_data',
            method: 'POST',
            timeout: 1000,
            data: 'limit='+ $scope.valueLimit +'&drmId=' + $scope.$parent.drmId,
            headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        }).success(
            function(response){
                if(response[0].active_power_a){ // 
                    //$scope.text = response[0].time;
                    $scope.lineData.labels = [0];
                    $scope.lineData.datasets[0].data = [0];
                    $scope.lineData.datasets[1].data = [0];
                    $scope.lineData.datasets[2].data = [0];

                    for (var i=0; i<response.length; i++) {
                        //length-i-1 used as index below because we receive the time values in reverse order
                        $scope.lineData.labels[response.length-i-1] = response[i].time;
                        $scope.lineData.datasets[0].data[response.length-i-1] = response[i].active_power_a*10;
                        $scope.lineData.datasets[1].data[response.length-i-1] = response[i].active_power_b*10;
                        $scope.lineData.datasets[2].data[response.length-i-1] = response[i].active_power_c*10;
                    }
                    $scope.date = response[0].date;
                    //$scope.drmId = response[0].energy_mon_id;
                    $scope.connectionLabel = "Database Connected";
                    $scope.connectionLabelColor = "label-primary";
                    //this.lineData.labels[1] = "test";
                    console.log($scope.refreshInterval);
                    //setTimeout(chartUpdate, $scope.refreshInterval * 1000);
                } else{
                    console.log("invalid response");
                    $scope.connectionLabel = "Database Unreachable";
                    $scope.connectionLabelColor = "label-danger";
                }
            }).error( 
            function(response){
                console.log("$http error");
                //$rootScope.drmId = "0";
                //$scope.drmId = $rootScope.drmId;
                $scope.connectionLabel = "Database Unreachable";
                $scope.connectionLabelColor = "label-danger";
            });
    };

    var interval = $interval(chartUpdate, $scope.refreshInterval * 1000);

    $scope.$watch("refreshInterval",function(newVal,oldVal){
        $interval.cancel(interval);
        chartUpdate();
        interval = $interval(chartUpdate, $scope.refreshInterval * 1000);
    });

    $scope.$watch("valueLimit",function(newVal,oldVal){
        chartUpdate();
    });

    $scope.$watch("$parent.drmId",function(newVal,oldVal){
        chartUpdate();
    });

    //The following listener is needed to cancel the interval when we switch scopes (== switch pages)
    //Otherwise multiple intervals are being created and maintained
    $scope.$on("$destroy", function () { $interval.cancel(interval); });

    /**
     * Data for Line chart
     */
    $scope.lineData = {
        labels: ["00:00:00"],
        datasets: [
            {
                label: "Power A",
                fillColor: "rgba(220,220,220,0.7)",
                strokeColor: "rgba(220,220,220,1)",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [0]
            },
            {
                label: "Power B",
                fillColor: "rgba(26,179,148,0.3)",
                strokeColor: "rgba(26,179,148,0.7)",
                pointColor: "rgba(26,179,148,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(26,179,148,1)",
                data: [0]
            },
            {
                label: "Power C",
                fillColor: "rgba(200,50,50,0.2)",
                strokeColor: "rgba(200,50,50,0.7)",
                pointColor: "rgba(200,50,50,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(200,50,50,1)",
                data: [0]
            }
        ]
    };

    /**
     * Options for Line chart
     */
    $scope.lineOptions = {
        animation: false,
        scaleShowGridLines : true,
        scaleGridLineColor : "rgba(0,0,0,.05)",
        scaleGridLineWidth : 1,
        bezierCurve : true,
        bezierCurveTension : 0.3,
        pointDot : true,
        pointDotRadius : 2,
        pointDotStrokeWidth : 1,
        pointHitDetectionRadius : 20,
        datasetStroke : true,
        datasetStrokeWidth : 2,
        datasetFill : true,
        responsive : true,
        maintainAspectRatio: false,
        showTooltips: true,
        multiTooltipTemplate: "<%= value %>",
        legendTemplate:"asdasd"
        //onAnimationComplete: function(){$scope.chart.lineOptions.animation = false;}
    };


};



function chartJsCtrl() {

    /**
     * Options for Bar chart
     */
    this.barOptions = {
        scaleBeginAtZero : true,
        scaleShowGridLines : true,
        scaleGridLineColor : "rgba(0,0,0,.05)",
        scaleGridLineWidth : 1,
        barShowStroke : true,
        barStrokeWidth : 2,
        barValueSpacing : 5,
        barDatasetSpacing : 1,
};

    /**
     * Data for Bar chart
     */
    this.barData = {
        labels: ["January", "February", "March", "April", "May", "June", "July"],
        datasets: [
            {
                label: "Scrapped",
                fillColor: "rgba(220,220,220,0.5)",
                strokeColor: "rgba(220,220,220,0.8)",
                highlightFill: "rgba(220,220,220,0.75)",
                highlightStroke: "rgba(220,220,220,1)",
                data: [65, 59, 80, 81, 56, 55, 40]
            },
            {
                label: "Sucessfully Refurbished",
                fillColor: "rgba(26,179,148,0.5)",
                strokeColor: "rgba(26,179,148,0.8)",
                highlightFill: "rgba(26,179,148,0.75)",
                highlightStroke: "rgba(26,179,148,1)",
                data: [28, 48, 40, 19, 86, 27, 90]
            }
        ]
    };

    /**
     * Data for Radar chart
     */
    




};


function voltageChartCtrl($scope, $http) {

    setInterval(function(){
        $http.get("resources/jsonVoltage.php")
        .success(function (response) {
            //$scope.text = response[0].time;
            for (var i=0; i<response.length; i++) {
                //length-i-1 used as index below because we receive the time values in reverse order
                $scope.chart.lineData.labels[response.length-i-1] = response[i].time;
                $scope.chart.lineData.datasets[0].data[response.length-i-1] = response[i].voltage_a/100;
                $scope.chart.lineData.datasets[1].data[response.length-i-1] = response[i].voltage_b/100;
                $scope.chart.lineData.datasets[2].data[response.length-i-1] = response[i].voltage_c/100;
            }
            //this.lineData.labels[1] = "test";
        });
    }, 1000);

    /**
     * Data for Line chart
     */
    this.lineData = {
        labels: ["00:00:00"],
        datasets: [
            {
                label: "Voltage A",
                fillColor: "rgba(220,220,220,0.7)",
                strokeColor: "rgba(220,220,220,1)",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [0]
            },
            {
                label: "Voltage B",
                fillColor: "rgba(26,179,148,0.3)",
                strokeColor: "rgba(26,179,148,0.7)",
                pointColor: "rgba(26,179,148,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(26,179,148,1)",
                data: [0]
            },
            {
                label: "Voltage C",
                fillColor: "rgba(200,50,50,0.2)",
                strokeColor: "rgba(200,50,50,0.7)",
                pointColor: "rgba(200,50,50,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(200,50,50,1)",
                data: [0]
            }
        ]
    };

    /**
     * Options for Line chart
     */
    this.lineOptions = {
        animation: false,
        scaleShowGridLines : true,
        scaleGridLineColor : "rgba(0,0,0,.05)",
        scaleGridLineWidth : 1,
        bezierCurve : true,
        bezierCurveTension : 0.3,
        pointDot : true,
        pointDotRadius : 2,
        pointDotStrokeWidth : 1,
        pointHitDetectionRadius : 20,
        datasetStroke : true,
        datasetStrokeWidth : 2,
        datasetFill : true,
        responsive : true,
        maintainAspectRatio: false,
        //onAnimationComplete: function(){$scope.chart.lineOptions.animation = false;}
    };


};
function powerChartCtrl($scope, $http) {

    setInterval(function(){
        $http.get("resources/jsonActive.php")
        .success(function (response) {
            //$scope.text = response[0].time;
            for (var i=0; i<response.length; i++) {
                //length-i-1 used as index below because we receive the time values in reverse order
                $scope.chart.lineData.labels[response.length-i-1] = response[i].time;
                $scope.chart.lineData.datasets[0].data[response.length-i-1] = response[i].active_power_a;
                $scope.chart.lineData.datasets[1].data[response.length-i-1] = response[i].active_power_b;
                $scope.chart.lineData.datasets[2].data[response.length-i-1] = response[i].active_power_c;
            }
            //this.lineData.labels[1] = "test";
        });
    }, 1000);

    /**
     * Data for Line chart
     */
    this.lineData = {
        labels: ["00:00:00"],
        datasets: [
            {
                label: "Power A",
                fillColor: "rgba(220,220,220,0.7)",
                strokeColor: "rgba(220,220,220,1)",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [0]
            },
            {
                label: "Power B",
                fillColor: "rgba(26,179,148,0.3)",
                strokeColor: "rgba(26,179,148,0.7)",
                pointColor: "rgba(26,179,148,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(26,179,148,1)",
                data: [0]
            },
            {
                label: "Power C",
                fillColor: "rgba(200,50,50,0.2)",
                strokeColor: "rgba(200,50,50,0.7)",
                pointColor: "rgba(200,50,50,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(200,50,50,1)",
                data: [0]
            }
        ]
    };

    /**
     * Options for Line chart
     */
    this.lineOptions = {
        animation: false,
        scaleShowGridLines : true,
        scaleGridLineColor : "rgba(0,0,0,.05)",
        scaleGridLineWidth : 1,
        bezierCurve : true,
        bezierCurveTension : 0.3,
        pointDot : true,
        pointDotRadius : 2,
        pointDotStrokeWidth : 1,
        pointHitDetectionRadius : 20,
        datasetStroke : true,
        datasetStrokeWidth : 2,
        datasetFill : true,
        responsive : true,
        maintainAspectRatio: false,
        //onAnimationComplete: function(){$scope.chart.lineOptions.animation = false;}
    };


};
function currentChartCtrl($scope, $http) {

    setInterval(function(){
        $http.get("resources/jsonCurrent.php")
        .success(function (response) {
            //$scope.text = response[0].time;
            for (var i=0; i<response.length; i++) {
                //length-i-1 used as index below because we receive the time values in reverse order
                $scope.chart.lineData.labels[response.length-i-1] = response[i].time;
                $scope.chart.lineData.datasets[0].data[response.length-i-1] = response[i].current_a;
                $scope.chart.lineData.datasets[1].data[response.length-i-1] = response[i].current_b;
                $scope.chart.lineData.datasets[2].data[response.length-i-1] = response[i].current_c;
            }
            //this.lineData.labels[1] = "test";
        });
    }, 1000);

    /**
     * Data for Line chart
     */
    this.lineData = {
        labels: ["00:00:00"],
        datasets: [
            {
                label: "Current A",
                fillColor: "rgba(220,220,220,0.7)",
                strokeColor: "rgba(220,220,220,1)",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [0]
            },
            {
                label: "Current B",
                fillColor: "rgba(26,179,148,0.3)",
                strokeColor: "rgba(26,179,148,0.7)",
                pointColor: "rgba(26,179,148,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(26,179,148,1)",
                data: [0]
            },
            {
                label: "Current C",
                fillColor: "rgba(200,50,50,0.2)",
                strokeColor: "rgba(200,50,50,0.7)",
                pointColor: "rgba(200,50,50,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(200,50,50,1)",
                data: [0]
            }
        ]
    };

    /**
     * Options for Line chart
     */
    this.lineOptions = {
        animation: false,
        scaleShowGridLines : true,
        scaleGridLineColor : "rgba(0,0,0,.05)",
        scaleGridLineWidth : 1,
        bezierCurve : true,
        bezierCurveTension : 0.3,
        pointDot : true,
        pointDotRadius : 2,
        pointDotStrokeWidth : 1,
        pointHitDetectionRadius : 20,
        datasetStroke : true,
        datasetStrokeWidth : 2,
        datasetFill : true,
        responsive : true,
        maintainAspectRatio: false,
        //onAnimationComplete: function(){$scope.chart.lineOptions.animation = false;}
    };


};


function bmreportsChartCtrl($scope, $http) {

    setInterval(function(){
        $http.get("resources/bmreports.php")
        .success(function (response) {
            //$scope.text = response[0].time;
            for (var i=0; i<response.SSB.length; i++) {
                //length-i-1 used as index below because we receive the time values in reverse order
                $scope.chart.lineData.labels[response.SSB.length-i-1] = response.SSB[i].SD;
                $scope.chart.lineData.datasets[0].data[response.SSB.length-i-1] = response.SSB[i].SSP;
                
            }
            //this.lineData.labels[1] = "test";
        });
    }, 1000);

    /**
     * Data for Line chart
     */
    this.lineData = {
        labels: ["00:00:00"],
        datasets: [
            {
                label: "SSP",
                fillColor: "rgba(220,220,220,0.7)",
                strokeColor: "rgba(220,220,220,1)",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                pointHighlightFill: "#fff",
                pointHighlightStroke: "rgba(220,220,220,1)",
                data: [0]
            },
            
        ]
    };

    /**
     * Options for Line chart
     */
    this.lineOptions = {
        animation: false,
        scaleShowGridLines : true,
        scaleGridLineColor : "rgba(0,0,0,.05)",
        scaleGridLineWidth : 1,
        bezierCurve : true,
        bezierCurveTension : 0.3,
        pointDot : true,
        pointDotRadius : 2,
        pointDotStrokeWidth : 1,
        pointHitDetectionRadius : 20,
        datasetStroke : true,
        datasetStrokeWidth : 2,
        datasetFill : true,
        responsive : true,
        maintainAspectRatio: false,
        //onAnimationComplete: function(){$scope.chart.lineOptions.animation = false;}
    };


};


function analyticsCtrl($scope,$http){
    $http.get("resources/analytics.php")
  .success(function (response) {
    $scope.Analytics = response;
  });
    
};




function idCtrl($scope, $http, $interval, $rootScope){

    var idGet = function(){
        $http.get("resources/drm_ids.php")
        .success(function(response){
                //$scope.text = response[0].time;
                $scope.data.availableOptions = [0];
                for (var i=0; i<response.length; i++) {
                    console.log(response[i].energy_mon_id);
                    //$scope.data.availableOptions[i].id = response[i].energy_mon_id;
                    $scope.data.availableOptions.push({id: response[i].energy_mon_id});
                    //Temperature update code follows:
                    if($scope.drmId == response[i].energy_mon_id){
                        $scope.time_tmp = response[i].time
                        $scope.date_tmp = response[i].date
                        $scope.ambient_tmp = response[i].last_ambient_tmp/100;
                        $scope.remote_tmp = response[i].last_remote_tmp/100;
                    }
                }
            }).error( 
            function(response){
                console.log(response[0]);
            });
    };

    $scope.data = {
    availableOptions: [0],
    selectedOption: {id: '0'} //This sets the default value of the select in the ui
    };

    idGet();

    var interval = $interval(idGet, 500);
    $scope.$on("$destroy", function () { $interval.cancel(interval); });

    $scope.$watch("data.selectedOption.id",function(newVal,oldVal){
        $scope.drmId = newVal;
    });
};

angular
    .module('inspinia')
    .controller('MainCtrl ', MainCtrl)
    .controller('voltageChartCtrl', voltageChartCtrl)
    .controller('powerChartCtrl', powerChartCtrl)
    .controller('currentChartCtrl', currentChartCtrl)
    .controller('chartJsCtrl',chartJsCtrl)
    .controller('idCtrl',idCtrl)
    .controller('bmreportsChartCtrl',bmreportsChartCtrl)
    .controller('analyticsCtrl',analyticsCtrl)
    
    


    

