/**
 * INSPINIA - Responsive Admin Theme
 * Copyright 2014 Webapplayers.com
 *
 */
(function () {
    angular.module('inspinia', [
        'ui.router',
        'ui.bootstrap',
        'angles',                       // Charts js
        'datatables',
        'db_table_views',// list of tables
        
    ])
})();