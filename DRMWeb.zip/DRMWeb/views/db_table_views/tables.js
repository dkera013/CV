
angular.module('db_table_views',['datatables'])
.controller('tableCtrl', ['$scope','$http', function ($scope,$http){

  $http.get("resources/bmreports.php")

  .success(function (response) {
    $scope.Reports = response;
  })
  
}])

.controller('analyticsCtrl', ['$scope', '$http', function($scope, $http){
  $http.get("resources/analytics.php")
  .success(function (response) {
    $scope.Analytics = response;
  })
  
    
}]);



