﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DEStoMySQLWS
{
    public partial class Form1 : Form
    {
        model model = new model();
        private double endTime;           // Simulation end time  


        public Form1()
        {
            InitializeComponent();
               
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            

            // Parse and validate
            try
            {

                endTime = Double.Parse(textBoxEndTime.Text);
            }
            catch
            {
                MessageBox.Show("Invalid parameters");
                return;
            }


            if (endTime <= 0)
            {
                MessageBox.Show("Invalid parameter");
                return;
            }
            
            textBox1.Text = model.Run(endTime);

                     
        }

        
    }
}
