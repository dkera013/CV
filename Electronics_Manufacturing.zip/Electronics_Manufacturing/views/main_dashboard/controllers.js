angular.module('factorydash',['datatables', 'angles'])
    .controller('factoryCtrl', ['$scope', '$http',  function($scope, $http){
            
            //Test Data
        $scope.userName = 'Example user';
        $scope.helloText = 'Number of Products Refurbished';
        $scope.descriptionText = 'Product Breakdown';
        $scope.products_refirbed ='256';
        $scope.asset_queue= [
                {
                    id:585738,
                    br_number:11112,
                    type:"phone",
                    manufacturer:"Apple",
                    model:"Iphone 4S"
                },
                {
                    id:425638,
                    br_number:11113,
                    type:"phone",
                    manufacturer:"Blackberry",
                    model:"402"
                },
                {
                    id:585738,
                    br_number:11112,
                    type:"laptop",
                    manufacturer:"Dell",
                    model:"677"
                }
            ];
            
            
         /**
         * Options for Bar chart
         */
        $scope.barOptions = {
            scaleBeginAtZero : true,
            scaleShowGridLines : true,
            scaleGridLineColor : "rgba(0,0,0,.05)",
            scaleGridLineWidth : 1,
            barShowStroke : true,
            barStrokeWidth : 2,
            barValueSpacing : 5,
            barDatasetSpacing : 1,
        };

        /**
         * Data for Bar chart
         */
        $scope.barData = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [
                {
                    label: "Scrapped",
                    fillColor: "rgba(220,220,220,0.5)",
                    strokeColor: "rgba(220,220,220,0.8)",
                    highlightFill: "rgba(220,220,220,0.75)",
                    highlightStroke: "rgba(220,220,220,1)",
                    data: [65, 59, 80, 81, 56, 55, 40]
                },
                {
                    label: "Sucessfully Refurbished",
                    fillColor: "rgba(26,179,148,0.5)",
                    strokeColor: "rgba(26,179,148,0.8)",
                    highlightFill: "rgba(26,179,148,0.75)",
                    highlightStroke: "rgba(26,179,148,1)",
                    data: [28, 48, 40, 19, 86, 27, 90]
                }
            ]
        };

        /**
         * Data for Line chart
         */
        $scope.lineData = {
            labels: ["January", "February", "March", "April", "May", "June", "July"],
            datasets: [
                {
                    label: "2015",
                    fillColor: "rgba(220,220,220,0.5)",
                    strokeColor: "rgba(220,220,220,1)",
                    pointColor: "rgba(220,220,220,1)",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(220,220,220,1)",
                    data: [65, 59, 80, 81, 56, 55, 40]
                },
                {
                    label: "2014",
                    fillColor: "rgba(26,179,148,0.5)",
                    strokeColor: "rgba(26,179,148,0.7)",
                    pointColor: "rgba(26,179,148,1)",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "rgba(26,179,148,1)",
                    data: [28, 48, 40, 19, 86, 27, 90]
                }
            ]
        };

        /**
         * Options for Line chart
         */
        $scope.lineOptions = {
            scaleShowGridLines : true,
            scaleGridLineColor : "rgba(0,0,0,.05)",
            scaleGridLineWidth : 1,
            bezierCurve : true,
            bezierCurveTension : 0.4,
            pointDot : true,
            pointDotRadius : 4,
            pointDotStrokeWidth : 1,
            pointHitDetectionRadius : 20,
            datasetStroke : true,
            datasetStrokeWidth : 2,
            datasetFill : true,
            scaleShowLabels: true,
        };
    
        $scope.Products_Produced=true;
        $scope.Engery_cost=false;
            
        $scope.select_products_produced=function(){
            $scope.Products_Produced=true;
            $scope.Engery_cost=false;
        };
        
        $scope.select_energy_cost=function(){
            $scope.Products_Produced=false;
            $scope.Engery_cost=true;
        };
            
}]);