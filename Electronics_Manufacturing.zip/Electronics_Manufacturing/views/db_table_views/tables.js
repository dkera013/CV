
angular.module('db_table_views',['datatables'])
.controller('tableCtrl', ['$scope','$http', function ($scope,$http){

  $http.get("http://localhost/~dkera/Electronics_Manufacturing/resources/process.php")
  .success(function (response) {
    $scope.Processes = response;
  })
  
    
}])

.controller('tableMaintenanceCtrl', ['$scope', '$http', function($scope, $http){
  $http.get("http://localhost/~dkera/Electronics_Manufacturing/resources/maintenance.php")
  .success(function (response) {
    $scope.Maintenances = response;
  })
}]);