function tableCtrl($scope,$http){
    $http.get("http://localhost/~dkera/Electronics_Manufacturing/resources/process.php")
  .success(function (response) {
    $scope.Processes = response;
  })
    
};

angular
    .module('inspinia')
    .controller('MainCtrl ', MainCtrl)
    .controller('tableCtrl',tableCtrl)