/**
 * INSPINIA - Responsive Admin Theme
 * Copyright 2014 Webapplayers.com
 *
 */


/**
 * MainCtrl - controller
 */
function MainCtrl() {

    this.userName = 'Example user';
    this.helloText = 'Number of Products Refurbished';
    this.descriptionText = 'Product Breakdown';
    this.products_refirbed ='256';
    

};

function tableCtrl($scope,$http){
    $http.get("http://localhost/~dkera/Electronics_Manufacturing/resources/process.php")
  .success(function (response) {
    $scope.Processes = response;
  })
    
};

function tableMaintenanceCtrl($scope,$http){
    $http.get("http://localhost/~dkera/Electronics_Manufacturing/resources/maintenance.php")
  .success(function (response) {
    $scope.Maintenances = response;
  })
    
};



angular
    .module('inspinia')
    .controller('MainCtrl ', MainCtrl)
    .controller('tableCtrl',tableCtrl)
    .controller('tableMaintenanceCtrl',tableMaintenanceCtrl)
    
    

