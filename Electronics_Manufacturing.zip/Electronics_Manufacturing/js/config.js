/**
 * INSPINIA - Responsive Admin Theme
 * Copyright 2014 Webapplayers.com
 *
 * Inspinia theme use AngularUI Router to manage routing and views
 * Each view are defined as state.
 * Initial there are written stat for all view in theme.
 *
 */
function config($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("/main");
    $stateProvider
        .state('main', {
            url: "/main",
            templateUrl: "views/main_dashboard/main.html",
            data: { pageTitle: 'Factory Dashboard' }
        })
        .state('minor', {
            url: "/minor",
            templateUrl: "views/minor.html",
            data: { pageTitle: 'Minor View' }
        })
        .state('table', {
            url: "/table",
            templateUrl: "views/table_data_tables.html",
            data: { pageTitle: 'Data Tables' }
        })
        .state('controller', {
            url: "/controller",
            templateUrl: "views/db_table_views/table_data_tables.html",
            data: { pageTitle: 'Data Tables' }
        })
        .state('wip_overview', {
            url: "/wip_overview",
            templateUrl: "views/wip_overview/wip_overview.html",
            data: { pageTitle: 'WIP Overview' }
        })
        .state('defect_overview', {
            url: "/defect_overview",
            templateUrl: "views/defect_overview/defect_overview.html",
            data: { pageTitle: 'Defect Overview' }
        })
        
}
angular
    .module('inspinia')
    .config(config)
    .run(function($rootScope, $state) {
        $rootScope.$state = $state;
    });