/**
 * INSPINIA - Responsive Admin Theme
 * Copyright 2014 Webapplayers.com
 *
 */
(function () {
    angular.module('inspinia', [
        'ui.router',
        'ui.bootstrap',
        'angles',
        'datatables',                  // Dynamic tables
        'factorydash',
        'wip_overview',
        'defect_overview',
        'localytics.directives',        //chosen plugin
    ])
})();