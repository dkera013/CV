<?php

 
function init_database()
{
    $link = mysql_connect('158.125.161.156', 'ikera', 'p49p0DbW') or die('Could not connect: ' . mysql_error());
    mysql_select_db('RFIDlifeCyleMonitoring') or die('Could not select database');
    return $link;
}


function print_result($query)
{
    $result = mysql_query($query) or die('Query failed: ' . mysql_error());
    
     
    $rows = array();
    while($r = mysql_fetch_assoc($result)) {
        $rows[] = $r;
        
    }
   
    print json_encode($rows);
   
    mysql_free_result($result);
}

//works
function add_process()
{
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);
    foreach ($data->process as $process)
    {
        $query = "INSERT INTO Process (ProcessGroup, ProcessType) VALUES ('$process->ProcessGroup', '$process->ProcessType')";
        $result = mysql_query($query) or die('Query failed: ' . mysql_error());
        mysql_free_result($result);
    }
}

//works
function get_processes()
{
    //$query = "SELECT idProcess, ProcessGroup, ProcessType FROM Process";
    $query = "SELECT * FROM Process";
    
    print_result($query);
}

//works
function get_process($process_id)
{
    
    $query = "SELECT * FROM Process WHERE idProcess = $process_id";

    print_result($query);
}


$database = init_database();

header("Content-Type: application/json");

// Check for the path elements to see if we have a book id in the request path
$path = $_SERVER[PATH_INFO];    
if ($path != null)
{
    $path_params = spliti ("/", $path);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    add_process();
     
}

else if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
    //avoid sql injection and some problems that can be shown in some web servers
    if ($path_params[1] != null)
    {
	settype($path_params[1],'integer');
	get_process($path_params[1]);
    }
    else
    {
	get_processes();
    }
    
}




mysql_close($database);

?>
