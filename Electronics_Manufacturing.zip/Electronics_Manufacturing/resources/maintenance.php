<?php

 
function init_database()
{
    $link = mysqli_connect('158.125.161.156', 'ikera', 'p49p0DbW','RFIDlifeCyleMonitoring') or die('Could not connect: ' . mysqli_connect_error());
    
    return $link;
}


function print_result($query)
{
    $result = mysqli_query($query) or die('Query failed: ' . mysqli_connect_error());
    
     
    $rows = array();
    while($r = mysqli_fetch_assoc($result)) {
        $rows[] = $r;
        
    }
   
    print json_encode($rows);
   
    mysqli_free_result($result);
}

//works
function add_process()
{
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);
    foreach ($data->maintenance as $maintenance)
    {
        $query = "INSERT INTO Maintenance (message, comment) VALUES ('$maintenance->message', '$maintenance->comment')";
        $result = mysqli_query($query) or die('Query failed: ' . mysqli_connect_error());
        mysqli_free_result($result);
    }
}

//works
function get_maintenances()
{
    $query = "SELECT * FROM Maintenance";
    
    print_result($query);
}

//works
function get_maintenance($maintenance_id)
{
    
    $query = "SELECT * FROM Maintenance WHERE idMaintenance = $maintenance_id";

    print_result($query);
}


$database = init_database();

header("Content-Type: application/json");

// Check for the path elements to see if we have a book id in the request path
$path = $_SERVER[PATH_INFO];    
if ($path != null)
{
    $path_params = spliti ("/", $path);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
    add_maintenance();
     
}

else if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
    //avoid sql injection and some problems that can be shown in some web servers
    if ($path_params[1] != null)
    {
	settype($path_params[1],'integer');
	get_maintenance($path_params[1]);
    }
    else
    {
	get_maintenances();
    }
    
}

mysqli_close($database);

?>
