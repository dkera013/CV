﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Host
{
    class Program
    {
        static void Main(string[] args)
        {
            //don't forget to add project reference!!!
            using (System.ServiceModel.ServiceHost host = new 
                System.ServiceModel.ServiceHost(typeof(DEStoMySQLWS.DEStoMySQLWS)))
            {
                host.Open();
                Console.WriteLine("Host started @ " + DateTime.Now.ToString());
                Console.ReadLine();
            }

        }
    }
}
