﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Delsi;
using MySql.Data.MySqlClient;

namespace DEStoMySQLWS
{
    public partial class model : Component
    {
        private MySqlConnection conn;
        private MySqlCommand cmd_select;
        private MySqlCommand cmd_insert;
        private MySqlCommand cmd_delete_all;

        int process_id;
        int product_type;
        double product_id;
        int station_id;
        string process_type;
        double timeEntered;

        public model()

        {
            InitializeComponent();
            PopulateModel();
        }

       
        public model(IContainer container)
        {
            container.Add(this);
            PopulateModel();
            InitializeComponent();
        }

        private void PopulateModel()
        {
            tModel1.Add(Arrivals);
            tModel1.Add(QueueJetPrinter);
            tModel1.Add(JetPrinter);
            tModel1.Add(QueueScreenPrinter);
            tModel1.Add(ScreenPrinter);
            tModel1.Add(QueueSPI);
            tModel1.Add(SPI);
            tModel1.Add(QueuePickAndPlace);
            tModel1.Add(PickAndPlace);
            tModel1.Add(QueueAOI);
            tModel1.Add(AOI);
            tModel1.Add(QueueReflowOven);
            tModel1.Add(ReflowOven);
            tModel1.Add(QueueVapourPhase);
            tModel1.Add(VapourPhase);
            tModel1.Add(Exits);
        }

        

        private void Parts_OnPlanned(TScheduler sender)
        {
            

            sender.SetTime(60.0);
        }

        private void Arrivals_AfterGeneration(TEmitter sender, Transaction transaction)
        {
            station_id = 0;
            transaction.Tag = product_type;
        }

        private void Arrivals_OnRouting(TEmitter sender, Transaction transaction)
        {
            station_id = 0;
            double probability = tMultiRand1.Uni01();
            if (probability < 0.50)
            {
                sender.Send(QueueJetPrinter);
            }
            else
            {
                sender.Send(QueueScreenPrinter);
            }
            
        }

        private void QueueJetPrinter_OnRouting(TQueue sender, Transaction transaction)
        {
            station_id = 1;
            sender.Send(JetPrinter);
        }

        private void JetPrinter_OnEnter(TServer sender, Transaction transaction)
        {
            station_id = 1;
            sender.SetTime(tMultiRand1.Uniform(14.0, 20.0));
        }

        private void JetPrinter_OnExit(TServer sender, Transaction transaction)
        {
            station_id = 1;
            timeEntered = tModel1.SysTime;
        }

        private void JetPrinter_OnRouting(TServer sender, Transaction transaction)
        {
            station_id = 1;
            sender.Send(QueueSPI);
        }
        

       

        private void QueueScreenPrinter_OnRouting(TQueue sender, Transaction transaction)
        {
            station_id = 2;
            sender.Send(ScreenPrinter);
        }

        private void ScreenPrinter_OnEnter(TServer sender, Transaction transaction)
        {
            station_id = 2;
            sender.SetTime(tMultiRand1.Uniform(14.0, 20.0));
        }

        private void ScreenPrinter_OnExit(TServer sender, Transaction transaction)
        {
            station_id = 2;
        }

        private void ScreenPrinter_OnRouting(TServer sender, Transaction transaction)
        {
            station_id = 2;
            sender.Send(QueueSPI);
        }
        

        

        private void QueueSPI_OnRouting(TQueue sender, Transaction transaction)
        {
            station_id = 2;
            sender.Send(SPI);
        }

        private void SPI_OnEnter(TServer sender, Transaction transaction)
        {
            station_id = 3;
            sender.SetTime(tMultiRand1.Uniform(14.0, 20.0));
        }

        private void SPI_OnExit(TServer sender, Transaction transaction)
        {
            station_id = 3;
        }

        private void SPI_OnRouting(TServer sender, Transaction transaction)
        {
            station_id = 3;
            sender.Send(QueuePickAndPlace);
        }

        private void QueuePickAndPlace_OnRouting(TQueue sender, Transaction transaction)
        {
            station_id = 4;
            sender.Send(PickAndPlace);
        }

        private void PickAndPlace_OnEnter(TQueue sender, Transaction transaction)
        {
            station_id = 4;
            sender.SetTime(tMultiRand1.Uniform(14.0, 20.0));
        }

        private void PickAndPlace_OnExit(TQueue sender, Transaction transaction)
        {
            station_id = 4;
        }

        private void PickAndPlace_OnRouting(TQueue sender, Transaction transaction)
        {
            station_id = 4;
            sender.Send(QueueAOI);
        }

        private void QueueAOI_OnRouting(TQueue sender, Transaction transaction)
        {
            station_id = 5;
            sender.Send(AOI);
        }

        private void AOI_OnEnter(TServer sender, Transaction transaction)
        {
            station_id = 5;
            sender.SetTime(tMultiRand1.Uniform(14.0, 20.0));
        }

        private void AOI_OnExit(TServer sender, Transaction transaction)
        {
            station_id = 5;
        }

        private void AOI_OnRouting(TServer sender, Transaction transaction)
        {
            station_id = 5;
            double probability=tMultiRand1.Uni01();
            if (probability < 0.50)
            {
                sender.Send(QueueReflowOven);
            }
            else
            {
                sender.Send(QueueVapourPhase);
            }
            
        }
        private void QueueReflowOven_OnRouting(TQueue sender, Transaction transaction)
        {
            station_id = 6;
            sender.Send(ReflowOven);
        }

        private void ReflowOven_OnEnter(TServer sender, Transaction transaction)
        {
            station_id = 6;
            sender.SetTime(tMultiRand1.Uniform(14.0, 20.0));
        }

        private void ReflowOven_OnExit(TServer sender, Transaction transaction)
        {
            station_id = 6;
        }

        private void ReflowOven_OnRouting(TServer sender, Transaction transaction)
        {
            station_id = 6;
            sender.Send(Exits);
        }

        private void QueueVapourPhase_OnRouting(TQueue sender, Transaction transaction)
        {
            station_id = 7;
            sender.Send(VapourPhase);
        }

        private void VapourPhase_OnEnter(TServer sender, Transaction transaction)
        {
            station_id = 7;
            sender.SetTime(tMultiRand1.Uniform(14.0, 20.0));
        }

        private void VapourPhase_OnExit(TServer sender, Transaction transaction)
        {
            station_id = 7;
        }

        private void VapourPhase_OnRouting(TServer sender, Transaction transaction)
        {
            station_id = 7;
            sender.Send(Exits);
        }


        private void Exits_OnEnter(TTerminator sender, Transaction transaction)
        {

        }

        public string Run(double endTime)
        {
            // fill the warehouse with 10 products of type 1
            product_type = 3;
            Arrivals.Emit(10);

            // fill the warehouse with 4 products of type 2
            product_type = 4;
            Arrivals.Emit(5);

            
            
            string connString = "Server=158.125.161.156; uid=ikera; pwd=p49p0DbW; database=dan-test;";
            

            conn = new MySqlConnection(connString);

            
            //this implements the insert operation.

            cmd_insert = new MySqlCommand("insert into ProcessTable (ProcessId, ProductType, ProductId, ProcessType,StationId,Start_Time,End_Time) values (@processid, @producttype,@productid, @processtype,@stationid,@starttime,@endtime)", conn);
            cmd_insert.Parameters.Add(new MySqlParameter("@processid", process_id));
            cmd_insert.Parameters.Add(new MySqlParameter("@producttype", product_type));
            cmd_insert.Parameters.Add(new MySqlParameter("@productid", product_id));
            cmd_insert.Parameters.Add(new MySqlParameter("@processtype", process_type));
            cmd_insert.Parameters.Add(new MySqlParameter("@stationid", station_id));
            cmd_insert.Parameters.Add(new MySqlParameter("@starttime", tModel1.SysTime));
            cmd_insert.Parameters.Add(new MySqlParameter("@endtime", timeEntered));

            // this implements our select operation.
            cmd_select = new MySqlCommand("select * from ProcessTable where ProductId = @productid order by Id desc", conn);
            cmd_select.Parameters.Add(new MySqlParameter("@productid", product_type));

            // this implements our delete operation
            cmd_delete_all = new MySqlCommand("TRUNCATE ProcessTable", conn);
            // Open the connection to the database 
            
            
            conn.Open();
            // Clean-up database table before simulation
            cmd_delete_all.ExecuteNonQuery();
           //Simulate
            tModel1.Simulate(endTime);
            // close the connection to the database
            conn.Close();

            string results = tModel1.Report();
            tModel1.Reset();
            
            return results;
        }

        private void tModel1_AfterPass(TModel model, IBlock sender, IBlock receiver, Transaction transaction)
        {
           

            // insert a record into DB when a transaction enters the storage
            cmd_insert.Parameters[0].Value = process_id;
            cmd_insert.Parameters[1].Value = (int)transaction.Tag;  // Product type
            cmd_insert.Parameters[2].Value = transaction.Id;  // Product id
            cmd_insert.Parameters[3].Value = sender.Caption;
            cmd_insert.Parameters[4].Value = station_id;
            cmd_insert.Parameters[5].Value = tModel1.SysTime;
            cmd_insert.Parameters[6].Value = timeEntered;

 
            cmd_insert.ExecuteNonQuery();
            

        }


    }
}
