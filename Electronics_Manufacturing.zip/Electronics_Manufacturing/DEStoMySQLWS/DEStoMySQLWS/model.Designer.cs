﻿namespace DEStoMySQLWS
{
    partial class model
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Arrivals = new Delsi.TEmitter(this.components);
            this.QueueJetPrinter = new Delsi.TQueue(this.components);
            this.JetPrinter = new Delsi.TServer(this.components);
            this.Exits = new Delsi.TTerminator(this.components);
            this.tMultiRand1 = new Delsi.TMultiRand(this.components);
            this.tModel1 = new Delsi.TModel(this.components);
            this.Parts = new Delsi.TScheduler(this.components);
            this.QueueScreenPrinter = new Delsi.TQueue(this.components);
            this.ScreenPrinter = new Delsi.TServer(this.components);
            this.PickAndPlace = new Delsi.TQueue(this.components);
            this.QueueAOI = new Delsi.TQueue(this.components);
            this.AOI = new Delsi.TServer(this.components);
            this.QueueReflowOven = new Delsi.TQueue(this.components);
            this.QueueVapourPhase = new Delsi.TQueue(this.components);
            this.ReflowOven = new Delsi.TServer(this.components);
            this.VapourPhase = new Delsi.TServer(this.components);
            this.SPI = new Delsi.TServer(this.components);
            this.QueuePickAndPlace = new Delsi.TQueue(this.components);
            this.QueueSPI = new Delsi.TQueue(this.components);
            // 
            // Arrivals
            // 
            this.Arrivals.Caption = "Arrivals";
            this.Arrivals.Tag = null;
            this.Arrivals.AfterGeneration += new Delsi.TEmitter.EventHandler(this.Arrivals_AfterGeneration);
            this.Arrivals.OnRouting += new Delsi.TEmitter.EventHandler(this.Arrivals_OnRouting);
            // 
            // QueueJetPrinter
            // 
            this.QueueJetPrinter.Capacity = 0;
            this.QueueJetPrinter.Caption = "QueueJetPrinter";
            this.QueueJetPrinter.Tag = null;
            this.QueueJetPrinter.OnRouting += new Delsi.TQueue.EventHandler(this.QueueJetPrinter_OnRouting);
            // 
            // JetPrinter
            // 
            this.JetPrinter.Caption = "JetPrinter";
            this.JetPrinter.isInterruptible = false;
            this.JetPrinter.Tag = null;
            this.JetPrinter.OnRouting += new Delsi.TServer.EventHandler(this.JetPrinter_OnRouting);
            this.JetPrinter.OnExit += new Delsi.TServer.EventHandler(this.JetPrinter_OnExit);
            this.JetPrinter.OnEnter += new Delsi.TServer.EventHandler(this.JetPrinter_OnEnter);
            // 
            // Exits
            // 
            this.Exits.Caption = "Exits";
            this.Exits.Tag = null;
            this.Exits.TerminationFactor = 1;
            this.Exits.OnEnter += new Delsi.TTerminator.EventHandler(this.Exits_OnEnter);
            // 
            // tMultiRand1
            // 
            this.tMultiRand1.Seed = ((uint)(1000000000u));
            // 
            // tModel1
            // 
            this.tModel1.Tag = null;
            this.tModel1.AfterPass += new Delsi.TModel.AfterPassEventHandler(this.tModel1_AfterPass);
            // 
            // Parts
            // 
            this.Parts.Caption = "Parts";
            this.Parts.FirstTime = 0D;
            this.Parts.Tag = null;
            this.Parts.OnPlanned += new Delsi.TScheduler.EventHandler(this.Parts_OnPlanned);
            // 
            // QueueScreenPrinter
            // 
            this.QueueScreenPrinter.Capacity = 0;
            this.QueueScreenPrinter.Caption = "QueueScreenPrinter";
            this.QueueScreenPrinter.Tag = null;
            this.QueueScreenPrinter.OnRouting += new Delsi.TQueue.EventHandler(this.QueueScreenPrinter_OnRouting);
            // 
            // ScreenPrinter
            // 
            this.ScreenPrinter.Caption = "ScreenPrinter";
            this.ScreenPrinter.isInterruptible = false;
            this.ScreenPrinter.Tag = null;
            this.ScreenPrinter.OnRouting += new Delsi.TServer.EventHandler(this.ScreenPrinter_OnRouting);
            this.ScreenPrinter.OnExit += new Delsi.TServer.EventHandler(this.ScreenPrinter_OnExit);
            this.ScreenPrinter.OnEnter += new Delsi.TServer.EventHandler(this.ScreenPrinter_OnEnter);
            // 
            // PickAndPlace
            // 
            this.PickAndPlace.Capacity = 0;
            this.PickAndPlace.Caption = "PickAndPlace";
            this.PickAndPlace.Tag = null;
            this.PickAndPlace.OnRouting += new Delsi.TQueue.EventHandler(this.PickAndPlace_OnRouting);
            this.PickAndPlace.OnExit += new Delsi.TQueue.EventHandler(this.PickAndPlace_OnExit);
            this.PickAndPlace.OnEnter += new Delsi.TQueue.EventHandler(this.PickAndPlace_OnEnter);
            // 
            // QueueAOI
            // 
            this.QueueAOI.Capacity = 0;
            this.QueueAOI.Caption = "QueueAOI";
            this.QueueAOI.Tag = null;
            this.QueueAOI.OnRouting += new Delsi.TQueue.EventHandler(this.QueueAOI_OnRouting);
            // 
            // AOI
            // 
            this.AOI.Caption = "AOI";
            this.AOI.isInterruptible = false;
            this.AOI.Tag = null;
            this.AOI.OnRouting += new Delsi.TServer.EventHandler(this.AOI_OnRouting);
            this.AOI.OnExit += new Delsi.TServer.EventHandler(this.AOI_OnExit);
            this.AOI.OnEnter += new Delsi.TServer.EventHandler(this.AOI_OnEnter);
            // 
            // QueueReflowOven
            // 
            this.QueueReflowOven.Capacity = 0;
            this.QueueReflowOven.Caption = "QueueReflowOven";
            this.QueueReflowOven.Tag = null;
            this.QueueReflowOven.OnRouting += new Delsi.TQueue.EventHandler(this.QueueReflowOven_OnRouting);
            // 
            // QueueVapourPhase
            // 
            this.QueueVapourPhase.Capacity = 0;
            this.QueueVapourPhase.Caption = "QueueVapourPhase";
            this.QueueVapourPhase.Tag = null;
            this.QueueVapourPhase.OnRouting += new Delsi.TQueue.EventHandler(this.QueueVapourPhase_OnRouting);
            // 
            // ReflowOven
            // 
            this.ReflowOven.Caption = "ReflowOven";
            this.ReflowOven.isInterruptible = false;
            this.ReflowOven.Tag = null;
            this.ReflowOven.OnRouting += new Delsi.TServer.EventHandler(this.ReflowOven_OnRouting);
            this.ReflowOven.OnExit += new Delsi.TServer.EventHandler(this.ReflowOven_OnExit);
            this.ReflowOven.OnEnter += new Delsi.TServer.EventHandler(this.ReflowOven_OnEnter);
            // 
            // VapourPhase
            // 
            this.VapourPhase.Caption = "VaporPhase";
            this.VapourPhase.isInterruptible = false;
            this.VapourPhase.Tag = null;
            this.VapourPhase.OnRouting += new Delsi.TServer.EventHandler(this.VapourPhase_OnRouting);
            this.VapourPhase.OnExit += new Delsi.TServer.EventHandler(this.VapourPhase_OnExit);
            this.VapourPhase.OnEnter += new Delsi.TServer.EventHandler(this.VapourPhase_OnEnter);
            // 
            // SPI
            // 
            this.SPI.Caption = "SPI";
            this.SPI.isInterruptible = false;
            this.SPI.Tag = null;
            this.SPI.OnRouting += new Delsi.TServer.EventHandler(this.SPI_OnRouting);
            this.SPI.OnExit += new Delsi.TServer.EventHandler(this.SPI_OnExit);
            this.SPI.OnEnter += new Delsi.TServer.EventHandler(this.SPI_OnEnter);
            // 
            // QueuePickAndPlace
            // 
            this.QueuePickAndPlace.Capacity = 0;
            this.QueuePickAndPlace.Caption = "QueuePickAndPlace";
            this.QueuePickAndPlace.Tag = null;
            this.QueuePickAndPlace.OnRouting += new Delsi.TQueue.EventHandler(this.QueuePickAndPlace_OnRouting);
            // 
            // QueueSPI
            // 
            this.QueueSPI.Capacity = 0;
            this.QueueSPI.Caption = "QueueSPI";
            this.QueueSPI.Tag = null;
            this.QueueSPI.OnRouting += new Delsi.TQueue.EventHandler(this.QueueSPI_OnRouting);

        }

        #endregion

        private Delsi.TEmitter Arrivals;
        private Delsi.TQueue QueueJetPrinter;
        private Delsi.TServer JetPrinter;
        private Delsi.TTerminator Exits;
        private Delsi.TMultiRand tMultiRand1;
        private Delsi.TModel tModel1;
        private Delsi.TScheduler Parts;
        private Delsi.TQueue QueueScreenPrinter;
        private Delsi.TServer ScreenPrinter;
        private Delsi.TQueue PickAndPlace;
        private Delsi.TQueue QueueAOI;
        private Delsi.TServer AOI;
        private Delsi.TQueue QueueReflowOven;
        private Delsi.TQueue QueueVapourPhase;
        private Delsi.TServer ReflowOven;
        private Delsi.TServer VapourPhase;
        private Delsi.TServer SPI;
        private Delsi.TQueue QueuePickAndPlace;
        private Delsi.TQueue QueueSPI;
    }
}
